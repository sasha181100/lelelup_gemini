CONF = {
    "DATA_PDF_PATH" : "docs/pdfs/data.pdf",
    "GEMINI_MODEL_NAME" : "gemini-1.0-pro",
    "EMBEDDING_MODEL_NAME" : "models/embedding-001",
    "TEMPERATURE" : 0.1,
    "CHUNK_SIZE" : 1024,
    "CHUNK_OVERLAP" : 256
}