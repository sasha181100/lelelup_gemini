import os

import telebot

token = os.environ.get('BOT_TOKEN')
bot = telebot.TeleBot(token=token)
run = False
users = {}
from GPT.gpt import *
hello_txt = '''Привет! 👋 Я Иишка - Ваш помощник по миру Bigoland. 

У нас вы можете приобрести самые крутые конструкторы! 
Более 80 детских и взрослых транспортных средств от снегоката до электро-картинга из 1 коробки. 

Чем я могу Вам помочь? '''
@bot.message_handler(commands=['start'])
def start(message):
    users[message.from_user.id] = {}
    users[message.from_user.id]["chat_history"] = [f'''
    Пользователь: ""
    Менеджер: {hello_txt}''']


    bot.send_message(message.chat.id, hello_txt)

@bot.message_handler(commands=['help'])
def help(message):
    bot.send_message(message.chat.id, '''У бота имеется несколько комманд:
    /question - задать вопрос к базе.
    /stop - останавливает программу.
    ''')
@bot.message_handler(commands=['clear'])
def clear_history(message):
    users[message.from_user.id]["chat_history"] = [f'''
    Пользователь: ""
    Менеджер: {hello_txt}''']

@bot.message_handler(commands=['stop'])
def exitos(message):
    bot.stop_bot()



# def go_next(message_chat_id, data, user_id):
#     global run
#     if int(data) <= len(graph[room]) and len(data) >= 0:
#         img = open(path, 'rb')
#             bot.send_photo(message_chat_id, img)
#             img.close()
#             bot.send_message(message_chat_id, "Выше я показал тебе схему лабиринта. Не смотри туда если интересно сыграть снова. \n\n/exit для выхода\n /restart для того чтобы начать заново")
#         else:
#             users[user_id]['room'] = graph[room][int(data) - 1]
#             path = f"photos/{users[user_id]['room']}.png"
#             img = open(path, 'rb')
#             bot.send_photo(message_chat_id, img)
#             img.close()
#             bot.send_message(message_chat_id, f"Ты в комнате {users[user_id]['room']}\n")
#             room = users[user_id]['room']
#
#             i = 1
#             if len(graph[room]) == 0:
#                 if room == 21 or room == 24:
#                     bot.send_message(message_chat_id,
#                                      "Поздравляю! Ты нашел выход из лабиринта) А ведь он был достаточно запутан, сложен и опасен\n")
#                 else:
#                     bot.send_message(message_chat_id, "Увы( Тебя съел монст. Возврящайся)\n")
#                 path = f"photos/25.png"
#                 img = open(path, 'rb')
#                 bot.send_photo(message_chat_id, img)
#                 img.close()
#                 bot.send_message(message_chat_id,
#                                  "Выше я показал тебе схему лабиринта. Не смотри туда если интересно сыграть снова. \n\n/exit для выхода\n /restart для того чтобы начать заново")
#
#             else:
#                 markup = types.InlineKeyboardMarkup(row_width=2)
#                 i = 1
#                 for neighbour in graph[room]:
#                     # print(ans)
#                     x = types.InlineKeyboardButton(i, callback_data=i)
#                     markup.add(x)
#                     i += 1
#


@bot.message_handler(content_types=['text'])
def answer(message):
    user_id = message.from_user.id
    if message.text:
        try:
            ans = generate_answer(message.text, users[user_id]["chat_history"])
            bot.send_message(message.chat.id, ans)
            users[user_id]["chat_history"].append(f"Пользователь: {message.text}")
            users[user_id]["chat_history"].append(f"Менеджер: {ans}")
        except Exception as e:
            bot.send_message(message.chat.id, "Упс :( У нас возникли неполадки, Решаем проблему" + e.args[0])






# @bot.callback_query_handler(func=lambda call:True)
# def process_answer(callback):
#
#     user_id = callback.from_user.id
#     (callback.message.chat.id, callback.data, user_id)

bot.polling()