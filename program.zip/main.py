"""
This code is designed to implement a Retrieval-Augmented Generation system using Large Language Models.
It uses the Gemini model from Google Generative AI and LangChain for processing and generating responses based on the Nvidia 10-K report.
"""
import os

# Importing necessary libraries
# from google.colab import drive
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.chains import RetrievalQA
from Loader.loader import *
from Retriever.retriever import *
from GPT.gpt import *
# Constants
GOOGLE_API_KEY = os.environ.get('GOOGLE_API_KEY')  # Replace with your actual Google API key
DATA_PDF_PATH = "docs/pdfs/data.pdf"
GEMINI_MODEL_NAME = "gemini-pro"
EMBEDDING_MODEL_NAME = "models/embedding-001"
TEMPERATURE = 0.1
CHUNK_SIZE = 1024
CHUNK_OVERLAP = 256


# Function to mount Google Drive
def mount_drive():
    """
    Mounts the Google Drive to access files.
    """
    # drive.mount('/docs/drive')

# Function to convert text to Markdown format

# Function to load and split the PDF document
def load_and_split_pdf(pdf_path):
    """
    Loads a PDF document and splits it into pages.
    Args:
    pdf_path (str): Path to the PDF file.
    Returns:
    list: List of pages from the PDF document.
    """
    pdf_loader = PyPDFLoader(pdf_path)
    return pdf_loader.load_and_split()


# Function to set up the Gemini model
def setup_gemini_model(model_name, api_key, temperature):
    """
    Sets up the Gemini model for text generation.
    Args:
    model_name (str): Name of the Gemini model.
    api_key (str): API key for accessing Google Generative AI.
    temperature (float): Temperature setting for the model.
    Returns:
    ChatGoogleGenerativeAI: Configured Gemini model.
    """
    return ChatGoogleGenerativeAI(model=model_name, google_api_key=api_key, temperature=temperature,
                                  convert_system_message_to_human=True)


# Function to create embeddings and vector index
def create_embeddings_and_index(texts, model_name, api_key):
    """
    Creates embeddings for texts and builds a vector index for retrieval.
    Args:
    texts (list): List of texts to create embeddings for.
    model_name (str): Name of the embedding model.
    api_key (str): API key for accessing Google Generative AI.
    Returns:
    retriever: Vector index for text retrieval.
    """
    embeddings = GoogleGenerativeAIEmbeddings(model=model_name, google_api_key=api_key)
    # query_vector = embeddings.model.encode("Представь что ты ассистент в компании, занимающейся продажами конструкторов. Ответь на вопрос клиента используя только информацию из прикрепленных данных, не выдумывай. Итак вопрос клиента: \"сколько кг выдерживает металлический конструктор?\ Отвечай на русском языке")
    # type(Chroma.from_documents(texts, embeddings)
    vector_index = Chroma.from_documents(texts, embeddings).as_retriever(search_type="mmr", search_kwargs={"k": 5})
    # results = vector_index.search(query_vector, k=0)
    # print(results)
    return vector_index


# Function to create RAG QA Chain
def create_rag_qa_chain(model, vector_index):
    """
    Creates a Retrieval-Augmented Generation QA chain.
    Args:
    model (ChatGoogleGenerativeAI): Configured Gemini model.
    vector_index (retriever): Vector index for retrieval.
    Returns:
    RetrievalQA: Configured RAG QA Chain.
    """
    return RetrievalQA.from_chain_type(model, retriever=vector_index, return_source_documents=True)


# Main Execution Flow
def main():

    # for m in genai.list_models():
    #     if 'generateContent' in m.supported_generation_methods:
    #         print(m.name)
    # split_and_save("txt", "docs/txts/demo.txt")
    # test_prompt = '''Здравствуйте, подскажите габариты усиленного электро вело конструтора'''

    # for doc in docs:
    #     print(doc.page_content)
    # print(generate_answer(test_prompt, []))

    # user_promt = input()
    # print(generate_answer(user_promt))
    #
    # """
    # Main function to execute the RAG workflow.
    # """
    # # mount_drive()
    # # loader = TextLoader("docs/test.txt", encoding='utf-8')
    # # docs = loader.load()
    # with open("docs/txts/test.txt", "r", encoding="utf-8") as f:
    #     # Чтение содержимого файла
    #     contents = f.read()
    #
    # loader = WebBaseLoader(['https://youit.school/about', 'https://youit.school/teachers', 'https://youit.school/all-courses'])
    # documents = loader.load()
    # text_splitter = RecursiveCharacterTextSplitter(chunk_size=CHUNK_SIZE, chunk_overlap=CHUNK_OVERLAP)
    # docs = text_splitter.split_documents(documents)
    # gemini_model = setup_gemini_model(GEMINI_MODEL_NAME, GOOGLE_API_KEY, TEMPERATURE)
    #
    # vector_index = create_embeddings_and_index(docs, EMBEDDING_MODEL_NAME, GOOGLE_API_KEY)
    # print(vector_index)
    # # Creating RAG QA Chain
    # qa_chain = create_rag_qa_chain(gemini_model, vector_index)
    #
    # # Example Usage
    # question = '''
    #
    #
    #
    # result = qa_chain({"query": question})
    #
    # for doc in result['source_documents']:
    #     print(doc)
    #     print("_________________________________________")
    # print("Answer:", result["result"])


if __name__ == "__main__":
    main()